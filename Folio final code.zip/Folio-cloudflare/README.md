# Folio for your own Cloudflare account

This standalone source copy replaces ChatGPT authentication with Supabase email/password accounts and Google OAuth. It uses Cloudflare Workers for the app and your own D1 database for saved resumes. It does not change the original deployed Site.

Your supplied Supabase URL and publishable key are already in `lib/auth/config.ts`. These are public connection details, not admin credentials. The Google Client Secret belongs only in Supabase's provider settings.

## 1. Finish Supabase settings

In your Supabase project:

- Authentication -> Providers -> Email: enable signup; turn Confirm email OFF if you want immediate signup without verification.
- Authentication -> URL Configuration: set Site URL to `https://fluxcv.com`; add `https://fluxcv.com/auth/callback` as an allowed redirect. Add the corresponding www callback if you use www.
- Authentication -> Providers -> Google: enable Google, enter the Google OAuth Client ID and Client Secret, and save.
- In Google's Web application client, put the callback URL shown by Supabase in Authorized redirect URIs. This is the Supabase `/auth/v1/callback` URL, not the Folio `/auth/callback` route.
- While testing, configure Google Audience/test users as required by the Google console. Before public launch, complete its production/publishing requirements.

Both Google and email accounts are stored by Supabase. The name entered during signup is stored in user metadata. Folio's personal profile still collects resume details through its interview.

## 2. Install and open the source

Install Node.js 22.13 or newer from https://nodejs.org (an even-numbered LTS release). Extract this ZIP. Open the `Folio-cloudflare` folder in VS Code. Choose Terminal -> New Terminal.

Run each command below individually, in that folder:

```sh
npm ci
npx wrangler login
npx wrangler d1 create fluxcv-db
```

Wrangler login opens your browser. Sign in to your own Cloudflare account and approve Wrangler access. Creating the database prints its `database_id` UUID. Copy that ID, then run:

```sh
npm run configure:db
```

Paste the actual UUID when asked. The command updates `wrangler.jsonc`. If the database already exists, find its UUID in Cloudflare's D1 dashboard and use that ID instead. The ZIP contains a placeholder UUID for local testing; you must replace it before deploying.

## 3. Create the database tables and deploy

```sh
npm run db:migrate:remote
npm run typecheck
npm test
npm run build
npm run deploy
```

Approve applying the two migrations to your new D1 database when prompted. Deploy uses the generated `dist/server/wrangler.json`, not the source ZIP uploader. It prints a workers.dev address. No domain change is made by these commands.

To try login at the workers.dev address, add its exact `/auth/callback` URL to Supabase's allowed redirect URLs. If needed, also add that origin to Google's Web application client. Do not start a Google login until the callback URL is allowed.

## 4. Test before connecting your domain

- Create an email account with name, email, and a password of at least 8 characters.
- Refresh, navigate between pages, then close and reopen your browser. Your session should persist.
- Sign out, then sign in using the same email/password.
- Test Google with an allowed Google account.
- Use two separate accounts (an incognito browser is useful). Each should have its own workspace and resumes.
- Generate a fresh resume with a confirmed certification and export its PDF.

Signing in uses HttpOnly cookies. Production cookies are Secure, SameSite=Lax, host-only, and expire after 30 days without renewal. Access tokens are refreshed before expiry on app requests. Supabase session revocation or password changes may end a session sooner. A sign-in on workers.dev is not automatically shared with fluxcv.com; sign in again after changing domains.

## 5. Connect fluxcv.com

After the workers.dev version works, open Cloudflare -> Workers & Pages -> fluxcv -> Settings -> Domains & Routes -> Add -> Custom domain. Enter `fluxcv.com` and follow Cloudflare's instructions. Configure www separately if required. Review any conflicting records pointing to the old host before replacing them. Changing this domain affects where visitors land.

Keep Supabase's Site URL and callback allowlist aligned with the final domain. Leave account/token responses uncached; do not enable a Cloudflare Cache Everything rule for this app.

## Optional local development

```sh
npm run db:migrate:local
npm run dev
```

Open http://localhost:5173. For local Google tests, add `http://localhost:5173/auth/callback` to Supabase's allowed redirect URLs. Sign in at the same host consistently (localhost and 127.0.0.1 use different cookies). There is no fake development identity; local data also requires a real Supabase login.

## Existing data and limitations

This ZIP contains source code, assets, configuration, tests, and schema migrations. It does not contain any live Sites database or existing visitor accounts. Your new D1 database starts empty. Existing resumes remain on the old Site until deliberately exported/imported or migrated. Never assign an old account to an unverified email match.

The Clear account data control removes Folio data, not the user's Supabase login account. Password reset and account linking interfaces are not included in this change. Google will not work until you configure its provider in Supabase; email confirmation is controlled in your Supabase dashboard, not in this ZIP.

The implementation uses Supabase's documented Auth REST API, Web Crypto PKCE, server-verified users, automatic token refresh, and same-origin POST checks. Credentials are not stored in Folio's D1 database. Sign-in/signup initiation has a D1-backed limit of 20 attempts per visitor IP per minute.

46 automated tests and a production build were verified during preparation. These checks do not replace a live Google/email round trip after your account settings and Cloudflare deployment are complete. Live provider flows were not verified in this execution environment.

## Source map

- `components/folio/auth-form.tsx`: signup/login interface and Google entry button.
- `app/signin`, `app/signup`: public account pages.
- `app/api/auth/[action]/route.ts`: signup, sign-in, sign-out, and Google initiation.
- `app/auth/callback/route.ts`: exchanges the Google PKCE authorization code.
- `lib/auth`: public configuration, Auth REST calls, cookies, server user checks, rate limiting.
- `proxy.ts`: session refresh and cache protection.
- `lib/server.ts`: maps verified Supabase user IDs to D1 workspace ownership.
- `wrangler.jsonc`: your Worker and D1 configuration.
- `drizzle`: resume tables and authentication attempt limits.

The remaining product/docs describe the original resume engine and its capabilities; this README is the current authority for standalone authentication and deployment.

## Official references

- https://supabase.com/docs/guides/auth/passwords
- https://supabase.com/docs/guides/auth/social-login/auth-google
- https://github.com/supabase/auth/blob/master/openapi.yaml
- https://developers.cloudflare.com/workers/vite-plugin/reference/migrating-from-wrangler-dev/
- https://developers.cloudflare.com/d1/reference/migrations/
